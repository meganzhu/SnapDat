/*
 * Copyright 2011 Rubnatak Holding
 *
 * Licensed under the Lexicontext terms of use (the "Terms of Use");
 * you may not use this file except in compliance with the Terms of Use.
 * You may obtain a copy of the Terms of Use at
 * 
 *    http://www.lexicontext.com/terms.html
 *
 * as well as the LICENSE.txt file that is provided together with this 
 * software package.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the Terms of Use is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Terms of Use for the specific language governing permissions and
 * limitations under the Terms of Use.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

#import "Lexicontext.h"

/**
 * The Lexicontext Pronounce category adds the functionality of audio pronunciation for a given 
 * dictionary word. The word's pronunciation is looked up using a free service provided by www.merriam-webster.com
 *
 * IMPORTANT: Please review the notes below before using this method in your app.
 *
 * 1. Lexicontext is not affiliated in any way with merriam-webster.com. Merriam-webster.com contains 
 *    copyrighted material, trademarks, and other proprietary information and the word's audio may be 
 *    subject to copyright restrictions. Before using this category you need to make sure that your app 
 *    complies with merriam-webster.com's terms of use.
 * 2. the method(s) of this category may not work properly if merriam-webster.com chooses to modify their service's API.
 * 3. the method(s) of this category require that your app has a network connection to merriam-webster.com.
 *
 */

@interface Lexicontext (Pronounce) 

/**
 * This method attempts to asynchronously play the audio-pronunciation of the input word.
 * The word's pronunciation is looked up using a free service provided by www.merriam-webster.com
 *
 * @param word     the word whose pronunciation should be looked up
 */
- (void)pronounce:(NSString *)word;


/**
 * This method attempts to asynchronously play the audio-pronunciation of the input word.
 * The word's pronunciation is looked up using a free service provided by www.merriam-webster.com
 *
 * @param word     the word whose pronunciation should be looked up
 * @param target   the object defining the specified selector 
 * @param selector the selector to invoke when the operation is complete. 
 *                 The selector should accept a single  parameter and the type of that parameter must be NSNumber.
 *                 The value of this parameter will signify if the pronunciation was successful.
 *                 For example, if the signature of your selector is: -(void)pronounceCallback:(NSNumber *)status 
 *                 then you can get the status by calling [status boolValue].
 */
- (void)pronounce:(NSString *)word withTarget:(id)target selector:(SEL)selector;

/**
 * This method returns YES if the word can be pronounced 
 * Note: this method accesses www.merriam-webster.com synchronously
 *
 * @param word     the word to check
 */
- (BOOL)canPronounce:(NSString *)word;

@end

