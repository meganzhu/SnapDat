//
//  Lexicontext+Pronounce.m
//  Lexicontext Pronounce
//
//  Created by Ori Regev on 1/26/11.
//  Copyright 2011 Rubnatak Holding All rights reserved.
//

#import "Lexicontext+Pronounce.h"

#include <regex.h>

@implementation Lexicontext (Pronounce)

NSString * const kLexicontextWebsterDictionaryBase = @"http://www.merriam-webster.com/dictionary/";
NSString * const kLexicontextWebsterAudioBase = @"http://cougar.eb.com/soundc11/";
NSString * const kLexicontextWavFileName = @"lexicontext_word.wav";

SystemSoundID lexicontextPronounceSystemSoundId;
NSString *lexicontextPronounceSystemSoundWord;    
NSOperationQueue* lexicontextPronounceOperationsQueue;

// TODO: we can cache more than 1 URL...
NSString *lexicontextPronounceCachedAudioUrlWord;
NSURL *lexicontextPronounceCachedAudioUrl;

// asynchronously play the audio-pronunciation of the input word
- (void)pronounce:(NSString *)word{
    [self pronounce:word withTarget:nil selector:nil];
}

// asynchronously play the audio-pronunciation of the input word and invoke selector when pronounciation is finished
- (void)pronounce:(NSString *)word withTarget:(id)target selector:(SEL)selector{
        
    NSInvocation *invocation = nil;
    if (target != nil && selector != nil) {
        NSMethodSignature *sig = [target methodSignatureForSelector:selector];
        invocation = [NSInvocation invocationWithMethodSignature:sig];
        [invocation setTarget:target];
        [invocation setSelector:selector];        
    }
    NSDictionary *dataDict = invocation != nil ? 
        [NSDictionary dictionaryWithObjectsAndKeys:invocation, @"callbackInvocation", word, @"word", nil] :
        [NSDictionary dictionaryWithObjectsAndKeys:word, @"word", nil] ;
    NSInvocationOperation* theOp = [[[NSInvocationOperation alloc] initWithTarget:self 
                                                                         selector:@selector(pronounceWithDataAndCallbackInvocation:) 
                                                                           object:dataDict] autorelease];
    if (lexicontextPronounceOperationsQueue == nil) {
        lexicontextPronounceOperationsQueue = [[NSOperationQueue alloc] init];
    }
    [lexicontextPronounceOperationsQueue addOperation:theOp]; 
}

// sound playback is complete
- (void)soundDone{
    [lexicontextPronounceSystemSoundWord release];
    lexicontextPronounceSystemSoundWord = nil;
    if (lexicontextPronounceSystemSoundId != 0) {
        OSStatus status = AudioServicesDisposeSystemSoundID(lexicontextPronounceSystemSoundId);
        if (status != kAudioServicesNoError) {
            NSLog(@"Lexicontext: Failed to dispose system sound id");
        } 
        lexicontextPronounceSystemSoundId = 0;        
    }
}

// scrape the audio file URL
- (NSURL *)extractPronounceAudioLinkMWD:(NSString *)word {
    
    NSString *trimmed = [word stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if ([trimmed isEqualToString:lexicontextPronounceCachedAudioUrlWord] && lexicontextPronounceCachedAudioUrl != nil) {
        //NSLog(@"Cached URL (abs string): %@", [cachedAudioUrl absoluteString]);
        return lexicontextPronounceCachedAudioUrl; 
    } else {
        [lexicontextPronounceCachedAudioUrlWord release];
        [lexicontextPronounceCachedAudioUrl release];
    }

    NSString *encoded = [trimmed stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *base = [NSURL URLWithString:kLexicontextWebsterDictionaryBase];
    NSURL *lookupUrl = [NSURL URLWithString:encoded relativeToURL:base];
    NSStringEncoding encoding;
    NSError *error;
    NSString *dictionaryResponse = [NSString stringWithContentsOfURL:lookupUrl usedEncoding:&encoding error:&error];
    if (dictionaryResponse == nil) {
        NSLog(@"Lexicontext: Failed to fetch dictionary info from Merriam Webster: %@", trimmed);
        return nil;
    }
    
    const char *dictionaryResponseCString = [dictionaryResponse UTF8String];
    const char *pattern = "\"return au\\('([^']+)', '([^']+)'\\);\"";
    char buf[1024];
    regex_t regex;
    regmatch_t *matches;
    int result;
    
    result = regcomp(&regex, pattern, REG_EXTENDED);
    if (result != 0) {
        regerror(result, &regex, buf, sizeof(buf));
        regfree(&regex);
        return nil;
    }
    
    matches = (regmatch_t *)malloc( (regex.re_nsub + 1) * sizeof(regmatch_t));
    if (!matches) {
        NSLog(@"Lexicontext: Out of memory!");
        return nil;
    }
    
    NSURL *audioUrl = nil;
    result = regexec(&regex, dictionaryResponseCString, regex.re_nsub + 1, matches, 0);
    if (result != 0) {
        regerror( result, &regex, buf, sizeof(buf) );
    } 
    else {
        if (matches[1].rm_so != -1 && matches[2].rm_so != -1) {
            char match1[matches[1].rm_eo - matches[1].rm_so + 1];
            char match2[matches[2].rm_eo - matches[2].rm_so + 1];
            strncpy(match1, dictionaryResponseCString + matches[1].rm_so, matches[1].rm_eo - matches[1].rm_so);
            match1[sizeof(match1) - 1] = '\0';
            strncpy(match2, dictionaryResponseCString + matches[2].rm_so, matches[2].rm_eo - matches[2].rm_so);
            match2[sizeof(match2) - 1] = '\0';                        
            NSString *audioPath = [NSString stringWithFormat:@"%c/%s", match1[0], match1];
            NSURL *audioBase = [NSURL URLWithString:kLexicontextWebsterAudioBase];
            audioUrl = [NSURL URLWithString:audioPath relativeToURL:audioBase];
        }
        else {
            return nil;
        }
    }
    
    free(matches);
    regfree(&regex);

    lexicontextPronounceCachedAudioUrlWord = trimmed;
    [lexicontextPronounceCachedAudioUrlWord retain];
    lexicontextPronounceCachedAudioUrl = audioUrl;
    [lexicontextPronounceCachedAudioUrl retain];
    
    return audioUrl;
}

// invoke pronounciation callback 
- (void)invokePronounceCallback:(NSInvocation *)invocation success:(BOOL)success {
    if (invocation != nil) {
        NSNumber *result = [NSNumber numberWithBool:success];
        [invocation setArgument:&result atIndex:2];
        [invocation invoke];        
    }    
}

// get a path to a file in a docs dir
- (NSString *)localFilePath:(NSString *)fileName {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:fileName];
}

// play the word's audio file
- (BOOL)playSoundWithData:(NSData *)wavData word:(NSString *)word {
    NSString *path = [self localFilePath:kLexicontextWavFileName];
    NSError *error;
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        BOOL success = [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
        if (!success) {
            NSLog(@"Lexicontext: Failed to remove old audio file: %@", [error description]);
            return NO;            
        }            
    }
    BOOL success =[wavData writeToFile:path atomically:YES];
    if (!success) {
        NSLog(@"Lexicontext: Failed to save audio file");
        return NO;
    }
    
    OSStatus status = AudioServicesCreateSystemSoundID((CFURLRef) [NSURL fileURLWithPath:path], &lexicontextPronounceSystemSoundId); 
    if (status == kAudioServicesNoError) {
        lexicontextPronounceSystemSoundWord = [NSString stringWithString:word];
        [lexicontextPronounceSystemSoundWord retain];
        AudioServicesPlaySystemSound(lexicontextPronounceSystemSoundId);            
        return YES;
    } 
    else {
        NSLog(@"Lexicontext: Failed to create word audio (status=%ld)", status);
        return NO;
    }
}

// play the word's audio file
- (BOOL)playSoundWithUrl:(NSURL *)url word:(NSString *)word{
    
    // No cached sound, but url is nil - internal error
    if (url == nil && lexicontextPronounceSystemSoundId == 0) {
        NSLog(@"Lexicontext: No cached sound, but url is nil (internal error)");        
    }
    
    // sound was already fetched, so use the cached sound id
    if (lexicontextPronounceSystemSoundId != 0) {
        AudioServicesPlaySystemSound(lexicontextPronounceSystemSoundId);            
        return YES;
    }    
    
    NSData *wavData = [NSData dataWithContentsOfURL:url];
    if (wavData != nil) {
        return [self playSoundWithData:wavData word:word];
    } 
    else {
        return NO;
    }
    
}

- (void)pronounceWithDataAndCallbackInvocation:(id)dataDict{
    
    NSURL *audioUrl = nil;
    NSString *word = (NSString *)[dataDict objectForKey:@"word"];
    NSInvocation *callbackInvocation = (NSInvocation *)[dataDict objectForKey:@"callbackInvocation"];
    
    if (lexicontextPronounceSystemSoundId != 0 && ![lexicontextPronounceSystemSoundWord isEqualToString:word]) {
        // dispose the previously cached sound
        [self soundDone];
    }
    
    // no cached sound so we need to extract a new url
    if (lexicontextPronounceSystemSoundId == 0) {
        audioUrl = [self extractPronounceAudioLinkMWD:word];
        if (audioUrl == nil) {
            if (callbackInvocation != nil) {
                [self invokePronounceCallback:callbackInvocation success:NO];                
            }
            return;
        }
    }
    
    BOOL status = [self playSoundWithUrl:audioUrl word:word];
    [self invokePronounceCallback:callbackInvocation success:status];
    
}

// check if the input word can be pronounced
- (BOOL)canPronounce:(NSString *)word {
    NSURL *audioUrl = [self extractPronounceAudioLinkMWD:word];
    // TODO: we can be more efficient. Since we already download the data, why not cache it?
    return (audioUrl != nil && [NSData dataWithContentsOfURL:audioUrl] != nil);
}

- (void)dealloc {
    [lexicontextPronounceOperationsQueue release];
    [lexicontextPronounceCachedAudioUrlWord release];
    [lexicontextPronounceCachedAudioUrl release];

    [super dealloc];
}             
             
@end
